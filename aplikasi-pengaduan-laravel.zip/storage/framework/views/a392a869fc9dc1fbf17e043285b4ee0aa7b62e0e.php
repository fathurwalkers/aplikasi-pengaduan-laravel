<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<!-- Header Content Section -->
<?php $__env->startSection('header-content'); ?>
    Kritik dan Saran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="container">

                <form action="<?php echo e(route('post-pembuatan-kritiksaran')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <p class="text-dark">Silahkan masukkan kritik dan saran yang ingin anda sampaikan pada beberapa
                        form pengajuan
                        dibawah.</p>

                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="kritiksaran_keterangan">
                                    <h6>Keterangan</h6>
                                </label>
                                <input type="text" class="form-control" id="kritiksaran_keterangan"
                                    placeholder="Masukkan keterangan pengaduan..." name="kritiksaran_keterangan">
                            </div>
                        </div>

                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="kritiksaran_tipe">
                                    <h6>Tipe</h6>
                                </label>
                                <select class="form-control" id="kritiksaran_tipe" name="kritiksaran_tipe">
                                    <option default value="Kritik">Kritik</option>
                                    <option value="Saran">Saran</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end">
                            <button type="submit" class="btn btn-info btn-md">
                                Proses Kritik dan Saran
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <h5 class="my-auto text-dark">Daftar Kritik dan Saran</h5>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Keterangan</th>
                                    <th>Tipe</th>
                                    <th>Pengirim</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $kritiksaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center text-dark"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->kritiksaran_keterangan); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->kritiksaran_tipe); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->kritiksaran_pengirim); ?></td>
                                        <td class="text-center text-dark">
                                            <?php echo e(date('d/m/Y', strtotime($item->kritiksaran_tanggal))); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/kritiksaran/pembuatan-kritiksaran.blade.php ENDPATH**/ ?>