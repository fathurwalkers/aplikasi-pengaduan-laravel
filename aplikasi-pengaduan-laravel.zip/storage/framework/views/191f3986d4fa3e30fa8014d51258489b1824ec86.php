<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .card-deck {
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
        }

        .card {
            flex: 1 0 auto;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row mb-2">
        <div class="col-sm-7 col-md-7 col-lg-7">
            <h4>Informasi & Berita</h4>
        </div>
        <div class="col-sm-5 col-md-5 col-lg-5 d-flex justify-content-end">
            <button class="btn btn-sm btn-info mb-2" onclick="location.href = '<?php echo e(route('home')); ?>'">
                Kembali
            </button>
        </div>
    </div>



    <div class="row">

        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($berita->berita_judul, 40); ?></h5>
                    <p>
                        <?php switch($berita->berita_jenis):
                            case ('berita'): ?>
                                <button type="button" class="btn btn-warning btn-sm">
                                    <?php echo e(strtoupper($berita->berita_jenis)); ?>

                                </button>
                            <?php break; ?>

                            <?php case ('pengumuman'): ?>
                                <button type="button" class="btn btn-primary btn-sm">
                                    <?php echo e(strtoupper($berita->berita_jenis)); ?>

                                </button>
                            <?php break; ?>
                        <?php endswitch; ?>
                    </p>

                    <p>
                        <?php echo $berita->berita_isi; ?>

                    </p>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/home/lihat-informasi.blade.php ENDPATH**/ ?>