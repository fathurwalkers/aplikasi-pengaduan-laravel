<?php $__env->startSection('header-content', 'Login'); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card fat">
        <div class="card-body">
            <h4 class="card-title">Login</h4>
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <form action="<?php echo e(route('post-login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="login_username">Username</label>
                    <input name="login_username" id="login_username" type="text" class="form-control" autofocus>
                    <?php if(session('status_fail_username')): ?>
                        <div class="invalid-feedback">
                            <?php echo e(session('status_fail_username')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="login_password">Password
                        <a href="forgot.html" class="float-right">
                            Forgot Password?
                        </a>
                    </label>
                    <input name="login_password" id="login_password" type="password" class="form-control">
                    <?php if(session('status_fail_password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e(session('status_fail_password')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <div class="custom-checkbox custom-control">
                        <input type="checkbox" id="remember" class="custom-control-input">
                        <label for="remember" class="custom-control-label">Remember Me</label>
                    </div>
                </div>

                <div class="form-group m-0">
                    <button type="submit" class="btn btn-primary btn-block">
                        Login
                    </button>
                </div>
                <div class="mt-4 text-center">
                    Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar sekarang!</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/login.blade.php ENDPATH**/ ?>