<div>
    <nav class="navbar navbar-expand-lg navbar-primary bg-primary sticky-top">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <b>
                <span style="color: #fff;">
                    SISTEM INFORMASI PENGADUAN WARGA
                </span>
            </b>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <?php if($users !== null): ?>
                    <li class="nav-item">
                        <button class="btn btn-sm btn-grey mr-1 my-auto nav-link text-dark" type="button"
                            onclick="location.href = '<?php echo e(route('dashboard')); ?>'">
                            <b>
                                Dashboard
                            </b>
                        </button>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <button class="btn btn-sm btn-grey mr-1 my-auto nav-link text-dark" type="button"
                            onclick="location.href = '<?php echo e(route('login')); ?>'">
                            <b>
                                Login
                            </b>
                        </button>
                    </li>
                <?php endif; ?>
                <?php if($users !== null): ?>
                    <li class="nav-item">
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-danger mr-1 my-auto nav-link text-white" type="submit">
                                <b>
                                    Logout
                                </b>
                            </button>
                        </form>
                    </li>
                <?php endif; ?>
                
            </ul>
        </div>
    </nav>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/components/home-navbar.blade.php ENDPATH**/ ?>