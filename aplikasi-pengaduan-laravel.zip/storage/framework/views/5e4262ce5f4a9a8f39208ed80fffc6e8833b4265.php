<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .card-deck {
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
        }

        .card {
            flex: 1 0 auto;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <h4>Informasi & Berita</h4>
        </div>
    </div>

    <div class="row">

        <div class="col-sm-12 col-md-12 col-lg-12">

            <div class="row">

                <div class="card-deck">
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-6 col-lg-6 d-flex align-items-stretch">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e(Str::limit($item->berita_judul, 40)); ?></h5>
                                    <p>
                                        <?php switch($item->berita_jenis):
                                            case ('berita'): ?>
                                                <button type="button" class="btn btn-warning btn-sm">
                                                    <?php echo e(strtoupper($item->berita_jenis)); ?>

                                                </button>
                                            <?php break; ?>

                                            <?php case ('pengumuman'): ?>
                                                <button type="button" class="btn btn-primary btn-sm">
                                                    <?php echo e(strtoupper($item->berita_jenis)); ?>

                                                </button>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <small class="text-muted"><?php echo e(date('d/m/Y', strtotime($item->berita_tanggal))); ?></small>
                                    <button type="button" class="btn btn-success btn-sm float-right"
                                        onclick="location.href = '<?php echo e(route('lihat-informasi', $item->id)); ?>'">
                                        Selengkapnya
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>

        </div>

        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/home/index.blade.php ENDPATH**/ ?>