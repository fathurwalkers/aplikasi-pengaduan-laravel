<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<!-- Header Content Section -->
<?php $__env->startSection('header-content'); ?>
    <?php switch($users->login_level):
        case ('user'): ?>
            Pembuatan Surat
        <?php break; ?>

        <?php case ('admin'): ?>
            Kelola Surat
        <?php break; ?>
    <?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if($users->login_level == 'user'): ?>
        <div class="card">
            <div class="card-body">
                <div class="container">

                    <form action="<?php echo e(route('post-pembuatan-surat')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <p class="text-dark">
                            Silahkan melakukan pengisian sesuai format surat yang telah ditentukan untuk melakukan
                            pengiriman surat.
                        </p>

                        <hr />
                        <div class="row">
                            <div class="col-12">
                                <p class="text-dark">Isikan informasi Data Diri Pelampir : </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_nama">
                                        <h6>Pengirim</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_pelampir_nama"
                                        placeholder="Masukkan keterangan pengaduan..." name="surat_pelampir_nama"
                                        value="<?php echo e($users->login_nama); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_tgllahir">
                                        <h6>Tanggal Lahir</h6>
                                    </label>
                                    <input type="date" class="form-control" id="surat_pelampir_tgllahir"
                                        name="surat_pelampir_tgllahir" value="<?php echo e(old('surat_pelampir_tgllahir')); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_pekerjaan">
                                        <h6>Pekerjaan</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_pelampir_pekerjaan"
                                        placeholder="Masukkan keterangan pengaduan..." name="surat_pelampir_pekerjaan"
                                        value="<?php echo e(old('surat_pelampir_pekerjaan')); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_statusperkawinan">
                                        <h6>Status Pekawinan</h6>
                                    </label>
                                    <select class="form-control" id="surat_pelampir_statusperkawinan"
                                        name="surat_pelampir_statusperkawinan"
                                        value="<?php echo e(old('surat_pelampir_statusperkawinan')); ?>">
                                        <option default value="menikah">Menikah</option>
                                        <option value="belum menikah">Belum Menikah</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_jenkel">
                                        <h6>Jenis Kelamin</h6>
                                    </label>
                                    <select class="form-control" id="surat_pelampir_jenkel" name="surat_pelampir_jenkel">
                                        <option default value="L">Laki-Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_pelampir_kewarganegaraan">
                                        <h6>Kewarganegaraan</h6>
                                    </label>
                                    <select class="form-control" id="surat_pelampir_kewarganegaraan"
                                        name="surat_pelampir_kewarganegaraan">
                                        <option default value="WNI">WNI</option>
                                        <option value="WNA">WNA</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label for="surat_pelampir_goldarah">
                                        <h6>Gol. Darah</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_pelampir_goldarah"
                                        placeholder="Masukkan golongan darah pelampir..." name="surat_pelampir_goldarah">
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label for="surat_pelampir_alamat">
                                        <h6>Alamat</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_pelampir_alamat"
                                        placeholder="Masukkan alamat pelampir..." name="surat_pelampir_alamat">
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label for="surat_pelampir_agama">
                                        <h6>Agama</h6>
                                    </label>
                                    <select class="form-control" id="surat_pelampir_agama" name="surat_pelampir_agama">
                                        <option default value="islam">Islam</option>
                                        <option value="kristen">Kristen</option>
                                        <option value="Protestan">Protestan</option>
                                        <option value="katolik">Katolik</option>
                                        <option value="Hindu">Hindu</option>
                                        <option value="Buddha">Hindu</option>
                                        <option value="konghucu">Konghucu</option>
                                        <option value="lainnya">Lainnya...</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <hr />
                        <div class="row">
                            <div class="col-12">
                                <p class="text-dark">Isikan informasi Pengajuan Surat : </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_perihal">
                                        <h6>Perihal</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_perihal"
                                        placeholder="Masukkan Perihal lampiran surat..." name="surat_perihal"
                                        value="<?php echo e(old('surat_perihal')); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_lampiran">
                                        <h6>Lampiran</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_lampiran"
                                        placeholder="Masukkan lampiran surat..." name="surat_lampiran">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_nomor">
                                        <h6>Nomor Surat</h6>
                                    </label>
                                    <input type="text" class="form-control" id="surat_nomor"
                                        placeholder="Masukkan keterangan pengaduan..." name="surat_nomor">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="surat_jenis">
                                        <h6>Jenis Keperluan</h6>
                                    </label>
                                    <select class="form-control" id="surat_jenis" name="surat_jenis">
                                        <option default value="surat_usaha">Surat Usaha</option>
                                        <option value="surat_kematian">Surat Kematian</option>
                                        <option value="surat_domisili">Surat Domisili</option>
                                        <option value="surat_pengantar_nikah">Surat Pengantar Nikah</option>
                                        <option value="surat_izin_keramaian">Surat Izin Keramaian</option>
                                        <option value="surat_keterangan_ahli_waris">Surat Keterangan Ahli Waris</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Dokumen Pendukung</span>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="surat_dokumen"
                                            name="surat_dokumen">
                                        <label class="custom-file-label" for="surat_dokumen">Choose file</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <label for="berita_isi">
                                    <h6 class="text-dark">Isi Surat</h6>
                                </label>
                                <textarea id="berita_isi" name="surat_isi" required></textarea>
                            </div>
                        </div>

                        <div class="row mt-1 mb-2">
                            <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-info btn-md">
                                    Proses Surat
                                </button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <h5 class="my-auto text-dark">Daftar Surat</h5>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th class="text-center text-dark">No.</th>
                                    <th class="text-center text-dark">Pengirim</th>
                                    <th class="text-center text-dark">Perihal</th>
                                    <th class="text-center text-dark">Keperluan</th>
                                    <th class="text-center text-dark">Kode Surat</th>
                                    <th class="text-center text-dark">Status</th>
                                    <th class="text-center text-dark">Tanggal</th>
                                    <th class="text-center text-dark">Dokumen</th>
                                    <th class="text-center text-dark">Kelola</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center text-dark"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->surat_pengirim); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->surat_perihal); ?></td>
                                        <td class="text-center text-dark">
                                            <?php echo e(ucwords(str_replace('_', ' ', $item->surat_jenis))); ?>

                                        </td>
                                        <td class="text-center text-dark"><?php echo e($item->surat_kode); ?></td>
                                        <td class="text-center text-dark">
                                            <?php switch($item->surat_status):
                                                case ('diproses'): ?>
                                                    <div class="col-sm-12 col-md-12 col-lg-12 mb-1 btn-block">
                                                        <button class="btn btn-sm btn-warning text-dark mb-1">
                                                            <b><?php echo e(strtoupper($item->surat_status)); ?></b>
                                                        </button>

                                                        <?php if($users->login_level == 'admin'): ?>
                                                            <div class="dropdown">
                                                                <button class="btn btn-info dropdown-toggle" type="button"
                                                                    id="dropdownMenuButton" data-toggle="dropdown"
                                                                    aria-haspopup="true" aria-expanded="false">
                                                                    Proses
                                                                </button>
                                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                    <form action="<?php echo e(route('konfirmasi-surat')); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="id_surat"
                                                                            value="<?php echo e($item->id); ?>">
                                                                        <button class="dropdown-item btn" type="submit"
                                                                            value="diterima"
                                                                            name="buttonkonfirmasi">Terima</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>

                                                    </div>
                                                <?php break; ?>

                                                <?php case ('diterima'): ?>
                                                    <button class="btn btn-sm btn-success text-dark mb-1">
                                                        <b><?php echo e(strtoupper($item->surat_status)); ?></b>
                                                    </button>
                                                <?php break; ?>
                                            <?php endswitch; ?>
                                        </td>
                                        <td class="text-center text-dark">
                                            <?php echo e(date('d/m/Y', strtotime($item->surat_tanggal))); ?>

                                        </td>
                                        <td class="text-center text-dark">
                                            <?php if($item->surat_dokumen == null): ?>
                                                <button type="button" class="btn btn-sm btn-info mr-1">
                                                    Kosong
                                                </button>
                                            <?php else: ?>
                                                <button type="button" id="buttonlihat<?php echo e($item->id); ?>"
                                                    class="btn btn-sm btn-primary mr-1" target="_blank"
                                                    onclick="openPDF('<?php echo e(asset('dokumen-surat')); ?>/<?php echo e($item->surat_dokumen); ?>')">
                                                    Cek
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="">
                                                <div class="col-sm-12 col-md-12 col-lg-12 btn-group">
                                                    <?php if($item->surat_dokumen !== null): ?>
                                                        <button type="button" id="buttonlihat<?php echo e($item->id); ?>"
                                                            class="btn btn-sm btn-success mr-1"
                                                            onclick="location.href = '<?php echo e(route('lihat-surat', $item->id)); ?>'">
                                                            Lihat
                                                        </button>
                                                    <?php endif; ?>
                                                    <button type="button" id="buttonlihat<?php echo e($item->id); ?>"
                                                        class="btn btn-sm btn-danger mr-1" data-toggle="modal"
                                                        data-target="#modalhapus<?php echo e($item->id); ?>">
                                                        Hapus
                                                    </button>
                                                </div>
                                            </div>

                                            <!-- Modal Hapus -->
                                            <div class="modal fade" id="modalhapus<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Hapus Data
                                                                Surat
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('hapus-surat', $item->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                Apakah anda yakin ingin menghapus data surat ini?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-danger">Hapus</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END Modal Hapus -->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
            $('#berita_isi').summernote();
        });

        function openPDF(params) {
            var pdfURL = params;
            window.open(pdfURL, '_blank');
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-pengaduan-laravel\resources\views/surat/pembuatan-surat.blade.php ENDPATH**/ ?>